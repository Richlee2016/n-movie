// 分组参数
export interface GroupItem{
    page?:number;
    size?:number;
    types?:number[];//分组类型
}